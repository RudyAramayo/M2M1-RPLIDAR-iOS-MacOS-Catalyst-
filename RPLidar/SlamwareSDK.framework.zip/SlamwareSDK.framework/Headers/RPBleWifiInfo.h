//
// Created by AlanLv on 4/12/16.
// Copyright (c) 2016 Shanghai Slamtec Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface RPBleWifiInfo : NSObject

@property (strong, nonatomic) NSString *ssid;
@property (strong, nonatomic) NSString *pwd;

@end